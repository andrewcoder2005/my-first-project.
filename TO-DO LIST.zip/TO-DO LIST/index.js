const express = require('express')
// const mongodb = require('mongodb')
// const mongoose = require('mongoose')
const dotenv = require('dotenv')
const {  connectDB, syncDB } = require('./configs/sequelize')
const TaskRoute = require('./routers/task.route')


const app = express()
// cách xài env
dotenv.config()
app.use(express.urlencoded())
app.use('/api/v1/tasks', TaskRoute)


// crud: create, read, update, delete

// xử lý các path bị lỗi hoặc sai path
app.get('*', (req, res) => { 
    res.json('Welcome to my api')
})

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
    connectDB();
    syncDB();
    console.log(`Sever is running on port: ${PORT}, with url: http://localhost:${PORT}`);
})