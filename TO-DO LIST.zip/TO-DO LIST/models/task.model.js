const { sequelize, DataTypes } = require('../configs/sequelize')
                                                                
const TaskModel = sequelize.define('Task', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
    }, 
    task_name: {
        type: DataTypes.STRING,
        allowNull: false 
    },
    is_complete: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false
    },
}, {
    tableName: 'Task',
    createdAt: 'created_at',
    updatedAt: 'updated_at'
})

module.exports = TaskModel

