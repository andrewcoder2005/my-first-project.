// 1. khai báo thư viện
const { Sequelize, DataTypes, Op } = require('sequelize')
//Sequelize là đối tượng chính để tương tác với cơ sở dữ liệu.
//DataTypes là một đối tượng cung cấp các kiểu dữ liệu được sử dụng trong cơ sở dữ liệu.
//Op cung cấp các toán tử so sánh.
    const dotenv = require('dotenv')
dotenv.config() 
//khởi mã đối tượng sequelize
const sequelize = new Sequelize( 
    process.env.MYSQL_DATABASE_NAME, 
    process.env.MYSQL_USERNAME, 
    process.env.MYSQL_PASSWORD, {
    host: 'localhost',
    dialect: 'mysql'
})  
    // hàm connectDB BÁO CÁO VÀ KIỂM TRA TRẠNG THÁI KẾT NỐI VỚI CƠ SỞ DỮ LIỆU 
async function connectDB() {
    try { 
        await sequelize.authenticate()
        console.log('Connection has been established successfully.');
    } catch(error) {
        console.log('Function connectDB has an error: ', error);
    }
}
// hàm syncDB  đảm bảo rằng cấu trúc của cơ sở dữ liệu MySQL phản ánh đúng cấu trúc của các mô hình Sequelize
async function syncDB() {
    try { 
        await sequelize.sync({ alter: true }) //Tham số { alter: true } được sử dụng để cho phép Sequelize tự động cập nhật cấu trúc bảng mà không làm mất dữ liệu hiện có.
        console.log('Sync database has been successfully.');
    } catch(error) {
        console.log('Function syncDB has an error: ', error);
    }
}

module.exports = {
    sequelize,
    DataTypes, 
    Op,
    connectDB,
    syncDB
}
