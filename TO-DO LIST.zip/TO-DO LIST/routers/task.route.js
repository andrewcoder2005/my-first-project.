const taskController = require("../controllers/task.controller")

const router = require("express").Router()

router.get("/get-all-tasks", taskController.getAllTasks)
router.post("/create-new-task", taskController.createNewTask)
router.put("/update-task/:id", taskController.updateTask)
router.delete("/delete-task/:id",taskController.deleteTask)

module.exports = router


