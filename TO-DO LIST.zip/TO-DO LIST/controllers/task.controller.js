const TaskModel = require('../models/task.model')

const taskController = {
    //C: Create
    createNewTask: async (req, res) => {
        try {
            const taskName = req.body.task_name
            const createTask = await TaskModel.create({ // insert into: la goi den mysql, createTask nhận dữ liệu từ  function bất đồng bộ TaskModel.create
                task_name: taskName
            })
            res.json({
                status_code: 200, // 200: mã thành          công, 500: mã thất bại
                message: "Create new task successfully",
                data: createTask
            })
        } catch(error) {
            console.log("Function creatNewTask has an error: ", error);
        }
    },
    // R: Read: đọc dữ liệu
    getAllTasks: async(req, res) => {
        try {
            const tasks = await TaskModel.findAll()
            res.json({
                status_code: 200,
                message: 'Read all tasks successfully',
                data: {
                    count: tasks.length,
                    tasks: tasks
                }
            })
        } catch(error) {
            console.log("Function getAllTasks has an error: ", error);
        }
    },
    // Update: cập nhật dữ liệu
    updateTask: async(req, res) => {
        try {
            const id = req.params.id
            const taskName = req.body.task_name
            const isComplete = req.body.is_complete
            const oldTask = await TaskModel.findByPk(id)
            const updateTask = await TaskModel.update({
                task_name: taskName || oldTask.getDataValue('task_name'),
                is_complete: isComplete || oldTask.getDataValue('is_complete')
            }, {
                where: {
                    id: id
                }
            }) // Update values (?,?) where id = 1

            if(updateTask[0] > 0) {
                const result = await TaskModel.findByPk(id)
                res.json({
                    status_code: 200,
                    message: 'Update task successfully',
                    data: result
                })
            } else {
                res.json({
                    status_code: 500,
                    message: 'Update task failure',
                })
            }
        } catch(error) {
            console.log("Function updateTask has an error: ", error);
        }
    },
    //Delete: : xóa dữ liệu
    deleteTask: async(req, res) => {
        try { 
             const id = req.params.id
             const deleteTask = await TaskModel.destroy({
                where: {
                    id: id
                }
             }) 
             res.json({
                status_code: 200,
                message:"Delete new task successfully",
             })
        } catch(error) {
            console.log("Function deleteTask has an error: ", error);
        }
    }
    
}

module.exports = taskController